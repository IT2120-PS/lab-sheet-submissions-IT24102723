# 1. Set working directory 
setwd("C:/Users/user/Desktop/IT24102723")

# 2. Import dataset
student_data <- read.csv("Exercise.csv", header = TRUE)

# View first few rows
head(student_data)

# Question 2: Summary statistics and Histogram for Age (X1)
summary(student_data$X1)

hist(student_data$X1,
     main = "Histogram of Student Age",
     xlab = "Age",
     col = "orange",        
     border = "darkred")    

# Question 3: Frequency table and Bar chart for Gender (X2)
# Frequency table
gender.freq <- table(student_data$X2)
gender.freq

# Add proper labels
names(gender.freq) <- c("Male", "Female")

# Bar chart with new colors
barplot(gender.freq,
        main = "Gender Distribution",
        xlab = "Gender",
        ylab = "Count",
        col = c("steelblue", "violet"),   
        border = "black")

# Question 4: Age vs Accommodation (X1 vs X3)
student_data$X3 <- factor(student_data$X3,
                          levels = c(1, 2, 3),
                          labels = c("Home", "Boarded", "Lodging"))

# Boxplot with new colors
boxplot(X1 ~ X3, data = student_data,
        main = "Age by Accommodation Type",
        xlab = "Accommodation Type",
        ylab = "Age",
        col = c("lightcoral", "lightseagreen", "khaki"),  
        border = "black")

student_data$X2 <- factor(student_data$X2,
                          levels = c(1, 2),
                          labels = c("Male", "Female"))

# Mean age grouped by Gender and Accommodation
aggregate(X1 ~ X2 + X3, data = student_data, FUN = mean)
