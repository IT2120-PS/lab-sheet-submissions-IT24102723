setwd("C:\\Users\\User\\Desktop\\IT24102723")

data<-read.table("Data - Lab 8.txt",header = TRUE)
fix(data)
attach(data)

popmn<-mean(Nicotine)
popmn

popvar<-var(Nicotine)
popvar

samples<-c()
n<-c()

for(i in 1:30){
  s<-sample(Nicotine,5,replace=TRUE)
  samples<-cbind(samples,s)
  n<-c(n,paste('S',i))
}

colnames(samples)=n

s.means<-apply(samples,2,mean)
s.vars<-apply(samples,2,var)
s.means
s.vars

samplemean<-mean(s.means)
samplemean

samplevars<-var(s.means)
samplevars

popmn
samplemean

truevar=popvar/5
samplevars
truevar




#Part 02

setwd("C:\\Users\\User\\Desktop\\IT24102723")

data<-read.table("Exercise - LaptopsWeights.txt",header = TRUE)
fix(data)
attach(data)

popmn<-mean(Weight.kg.)
popmn

popsd<-sd(Weight.kg.)
popsd

sample_names <- c()

for(i in 1:25){
  s <- sample(Weight.kg., 6, replace = TRUE)
  samples <- cbind(samples, s)
  sample_names <- c(sample_names, paste('S', i, sep=''))
}

colnames(samples) <- sample_names

sample_means <- apply(samples, 2, mean)
sample_sds <- apply(samples, 2, sd)

sample_means
sample_sds 

mean_of_sample_means <- mean(sample_means)
sd_of_sample_means <- sd(sample_means)

mean_of_sample_means  
sd_of_sample_means  

popmn
mean_of_sample_means

true_sd <- pop_sd / sqrt(6)
true_sd
sd_of_sample_means
